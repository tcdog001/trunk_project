#ifndef __PARTOOLAPI_H_049D6308912C0CFE63093A469A2476FB__
#define __PARTOOLAPI_H_049D6308912C0CFE63093A469A2476FB__
/******************************************************************************/

#ifdef __BOOT__
extern int
partool_show_byname_api(int argc, char *argv[],void *buf);
extern int
partool_new(int argc, char *argv[]);
extern inline void
partool_clean(void);


#endif

/******************************************************************************/
#endif /* __PARTOOL_H_049D6308912C0CFE63093A469A2476FB__ */
