#!/bin/bash

. ${__ROOTFS__}/etc/jsock/jsock.in


usage() {
	echo "jcmd usage:"
	echo "  jcmd {mode} {name} [args...]"
	echo "      mode: asyn/ack/syn"
	echo "      name: remote command name"
	echo "      args: remote command args"
	echo
}

#
#$1:mode
#$2:name
#[$3:args...]
#
main() {
	if [[ "$#" < "2" ]]; then
		usage

		return ${E_INVAL}
	fi

	jcmd "${JSOCK_PEER}" "$@"
}

main "$@"
