#!/bin/bash

. ${__ROOTFS__}/etc/jsock/jsock.in


usage() {
	echo "jmsg usage:"
	echo "  jmsg {mode} {name} {body}"
	echo "      mode: asyn/ack/syn"
	echo "      name: message name"
	echo "      body: message body, must json format"
	echo
}

#
#$1:mode
#$2:name
#$3:body...
#
main() {
	if [[ "$#" < "3" ]]; then
		usage

		return ${E_INVAL}
	fi

	jmsg "${JSOCK_PEER}" "$@"
}

main "$@"
