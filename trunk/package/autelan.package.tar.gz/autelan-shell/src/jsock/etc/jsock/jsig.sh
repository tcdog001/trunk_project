#!/bin/bash

. ${__ROOTFS__}/etc/jsock/jsock.in


usage() {
	echo "jsig usage:"
	echo "  jsig {mode} {name}"
	echo "      mode: asyn/ack/syn"
	echo "      name: signal name"
	echo
}

#
#$1:mode
#$2:name
#
main() {
	if [[ "2" != "$#" ]]; then
		usage

		return ${E_INVAL}
	fi

	jsig "${JSOCK_PEER}" "$@"
}

main "$@"
