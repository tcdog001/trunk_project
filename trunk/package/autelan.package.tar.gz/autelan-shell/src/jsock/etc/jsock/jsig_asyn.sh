#!/bin/bash

. ${__ROOTFS__}/etc/jsock/jsock.in


usage() {
	echo "jsig usage:"
	echo "  jsig {name}"
	echo "      name: signal name"
	echo
}

#
#$1:name
#
main() {
	if [[ "1" != "$#" ]]; then
		usage

		return ${E_INVAL}
	fi

	jsig "${JSOCK_PEER}" "asyn" "$@"
}

main "$@"
