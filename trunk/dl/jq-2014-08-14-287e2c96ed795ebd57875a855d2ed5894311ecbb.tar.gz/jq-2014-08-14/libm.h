LIBM_DD(acos)
LIBM_DD(acosh)
LIBM_DD(asin)
LIBM_DD(asinh)
LIBM_DD(atan)
LIBM_DD(atanh)
LIBM_DD(cbrt)
LIBM_DD(cos)
LIBM_DD(cosh)
LIBM_DD(exp2)
LIBM_DD(exp)
LIBM_DD(floor)
LIBM_DD(j0)
LIBM_DD(j1)
LIBM_DD(log10)
LIBM_DD(log2)
LIBM_DD(log)
LIBM_DD(sin)
LIBM_DD(sinh)
LIBM_DD(sqrt)
LIBM_DD(tan)
LIBM_DD(tanh)
LIBM_DD(tgamma)
LIBM_DD(y0)
LIBM_DD(y1)
/* LIBM_DID(jn) */
/* LIBM_DID(yn) */
/* LIBM_DDD(pow) */
/* LIBM_DDD(atan2) */
/* LIBM_DDD(hypot) */
/* LIBM_DDD(remainder) */
/* LIBM_DDI(scalbn) */
/* LIBM_DDIP(lgamma_r) */

